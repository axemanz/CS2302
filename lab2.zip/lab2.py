# -*- coding: utf-8 -*-
"""
@course: CS2302

@author: Axel Manzanares

@Assignment: Sorting Algorithms

@instructor: Prof. Fuentes

@TA: Anindita Nath

Created on Mon Sep 16 18:09:19 2019

Last modified on Fri Sep 20 19:30:12 2019

"""

def select_bubble(L,k):
    if k > len(L)-1:                                                            #checks if inputed index k is not greater
        return 'inputed index does not exist, please try again'                 #than L
    else:    
        for i in range(len(L)):
            for j in range(len(L) - i - 1):                                     #Bubble Sort Algorithm
                if (L[j] > L[j+1]):
                    temp = L[j]
                    L[j] = L[j+1]
                    L[j+1] = temp
        return L[k]

def select_quick(L, k):
    if k > len(L)-1:
        return 'inputed index does not exist, please try again'
    else:
        n = len(L)-1
        sorted_list = quick_sort(L, 0, n)
        return sorted_list[k]
    
def select_modified_quick(L, k):
    if k > len(L)-1:
        return 'inputed index does not exist, please try again'
    else:
        l_lower = list()
        l_higher = list()
        pivot = L[0]
    
        for i in range(len(L)):                                                 #separates lower and higher sublist using
            if L[i] < pivot:                                                    #L
                l_lower.append(L[i])
            else:
                l_higher.append(L[i])
                
        if k <= len(l_lower)-1:                                                 #checks if the inputed k is less than lower
            n = len(l_lower)-1                                                  #sublist
            sorted_sublist = mod_quick_sort_if_low(l_lower, 0, n)               #calls mod_quick_sort_if_low method
            return sorted_sublist[k]
        else:
            n = len(l_higher)-1
            sorted_sublist = mod_quick_sort_if_high(l_higher, 0, n)             #calls mod_quick_sort_if_high method
            return sorted_sublist[k-len(l_lower)]
    
def quick_sort(L, low, high):                                                   #Quick Sort Algorithm
    if low < high:
        pi = partition(L, low, high)
        quick_sort(L, low, pi-1)
        quick_sort(L, pi+1, high)
    return L
        
def mod_quick_sort_if_low(L, low, high):
    if low < high:
        
        pi = partition(L, low, high)
        quick_sort(L, low, pi - 1)                                              #only partitions the lower half of L
    return L
        
def mod_quick_sort_if_high(L, low, high):
    if low < high:
        
        pi = partition(L, low, high)
        quick_sort(L, pi + 1, high)                                             #only partitions the higher half of L
    return L
        
def partition(L, low, high):
    pivot_value = L[low]
    border = low
    
    for i in range(low, high+1):
        if L[i] < pivot_value:
            border += 1
            L[i], L[border] = L[border], L[i]
    L[low], L[border] = L[border], L[low]
    return (border)
   
L = [5, 2, 7, 6, 1, 9, 4, 8] #random sorted list
L1 = [10, 9, 8, 7, 6, 5, 4, 3] #decreasing sorted list
L2 = [3, 4, 5, 6, 7, 8, 9, 10] #already sorted list
L3 = [] #empty list
L4 = [5] #one element list

print('testing for L')
input_index = int(input('please enter an index from 0 - 7: '))
print()
print('0 - random sorted list')
print('1 - decreasing sorted list')
print('2 - ascending sorted list')
print('3 - empty list')
print('4 - one element list')
print()

input_list = int(input('please choose a list to search index in: '))
if input_list == 0:
    input_list = L
if input_list == 1:
    input_list = L1
if input_list == 2:
    input_list = L2
if input_list == 3:
    input_list = L3
if input_list == 4:
    input_list = L4
print()

print('Bubble sort: ', select_bubble(input_list, input_index))

print()

print('Quick sort: ', select_quick(input_list, input_index))

print()

print('Modded Quick Sort: ', select_modified_quick(input_list, input_index))

print()




