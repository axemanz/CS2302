# -*- coding: utf-8 -*-
"""
Created on Mon Sep 30 17:37:07 2019

@author: amanz
"""
class Node(object):
    def __init__(self, data, next=None):  
        self.data = data
        self.next = next   
class SortedList(object):
    def __init__(self):
        self.head = None
        self.tail = None
    def Append(self, x): #append method for SortedList class
        if self.head is None:
            self.head = Node(x)
            self.tail = self.head
        else:
            self.tail.next = Node(x)
            self.tail = self.tail.next
        
    def Print(self):
        t = self.head
        while t is not None:
            print(t.data,end=' ')
            t = t.next
        print()
    def Insert(self,i):
        if self.head is None:
            self.head = Node(i)
            self.tail = self.head
        else:
            self.tail.next = Node(i)
            self.tail = self.tail.next
    def Delete(self,i):
        if self.head is None:
            return
        t = self.head
        while t.next is not None and t.next.data is not i:
            if t.data == i:
                t.next = t
                break
            else:    
                t = t.next
        if t.next is None:
            return
        else:  
            t.next = t.next.next
    def Merge(self,M):
        if self.head is None:
            self.head = M.head
            self.tail = M.tail
        else:
            t = self.head
            while t.next is not None:
                t = t.next
            t.next = M.head
            t.tail = M.tail
        return
    def IndexOf(self,i):
        count = 0
        t = self.head
        while t is not None and t.data is not i:
            count+=1
            t = t.next
        if t is None:
            print(-1)
        else:
            print(count)
    def Clear(self):
        self.head = self.tail.next
        return
    def Min(self):
        t = self.head
        temp = t.data
        while t is not None:
            if t.data < temp:
                temp = t.data
            t = t.next
        print(temp)
    def Max(self):
        t = self.head
        temp = t.data
        while t is not None:
            if t.data > temp:
                temp = t.data
            t = t.next
        print(temp)
    def HasDuplicates(self ):
        if self.head is None:
            print(-1)
            return
        if self.head.next is None:
            print(False)
            return
        t = self.head.next
        temp = self.head.data
        while t is not None:
            if t.data == temp:
                print(True)
                break
            t = t.next
        if t is None:
            print(False)
    def Select(self,k): #incomplete
        if self.head is None:
            print(-1)
            return
        if self.head.next is None:
            print(self.head)
            return
        t = self.head
        while t is not None:
            return
        return
    
L = SortedList()
M = SortedList()
L.Append(1)
L.Append(8)
L.Append(3)
L.Append(5)
M.Append(2)
M.Append(9)
M.Append(3)
M.Append(6)
L.Insert(4)
L.Delete(3)
L.Merge(M)
L.IndexOf(7)
L.Clear()
L.Min()
L.Max()
L.HasDuplicates()
L.Print()


